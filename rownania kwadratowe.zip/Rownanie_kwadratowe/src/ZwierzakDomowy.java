import java.time.LocalDate;
import java.time.Period;
public class ZwierzakDomowy {
    private String nazwa;
    private String gatunek;
    private LocalDate data_urodzenia;

    public ZwierzakDomowy(String nazwa, String gatunek, LocalDate data_urodzenia) throws NiepoprawnaDataException {
        if (data_urodzenia.isAfter(LocalDate.now()) || obliczWiek(data_urodzenia) > 25) {
            throw new NiepoprawnaDataException("Niepoprawna data urodzenia");
        }
        this.nazwa = nazwa;
        this.gatunek = gatunek;
        this.data_urodzenia = data_urodzenia;
    }

    public int obliczWiek(LocalDate data_urodzenia) {
        LocalDate dzisiaj = LocalDate.now();
        Period period = Period.between(data_urodzenia, dzisiaj);
        return period.getYears();
    }

    @Override
    public String toString() {
        return "Zwierzak domowy: " + nazwa + " (" + gatunek + "), urodzony/a " + data_urodzenia.toString() + ", wiek: " + obliczWiek(data_urodzenia) + " lat";
    }
}

