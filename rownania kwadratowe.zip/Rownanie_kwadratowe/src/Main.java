import java.time.LocalDate;
import java.time.Period;
public class Main {
    public static void main(String[] args) {
        //1 zadanie
        try {
            RownanieKwadratowe r = new RownanieKwadratowe(2, 7, 6);
            double[] wynik = r.obliczRozwiazania();
            System.out.println("x1 = " + wynik[0] + ", x2 = " + wynik[1]);
        } catch (DeltaUjemnaException ex) {
            System.out.println("Błąd: " + ex.getMessage());
        }

        //2 zadanie
        try {
            ZwierzakDomowy zwierzak = new ZwierzakDomowy("Burek", "Pies", LocalDate.of(2015, 4, 20));
            System.out.println(zwierzak.toString());
        } catch (NiepoprawnaDataException e) {
            System.out.println("Wyjątek: " + e.getMessage());
            ZwierzakDomowy zwierzak = null;
            try {
                zwierzak = new ZwierzakDomowy("Burek", "Pies", LocalDate.now());
            } catch (NiepoprawnaDataException e1) {
                System.out.println("Nie udało się utworzyć zwierzaka.");
            }
            if (zwierzak != null) {
                System.out.println(zwierzak.toString());
            }
        }






    }
}