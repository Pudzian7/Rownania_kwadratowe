class DeltaUjemnaException extends Exception {
    public DeltaUjemnaException(String message) {
        super(message);
    }
}