public class RownanieKwadratowe {
    private double a, b, c;

    public RownanieKwadratowe(double a, double b, double c) {

        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double obliczDelte() {
        return Math.pow(b, 2) - 4 * a * c;
    }

    public double[] obliczRozwiazania() throws DeltaUjemnaException {
        double delta = obliczDelte();
        if (delta < 0) {
            throw new DeltaUjemnaException("Delta mniejsza od zera: " + delta);
        } else if (delta == 0) {
            double[] wynik = new double[1];
            wynik[0] = (-b) / (2 * a);
            return wynik;
        } else {
            double[] wynik = new double[2];
            wynik[0] = (-b - Math.sqrt(delta)) / (2 * a);
            wynik[1] = (-b + Math.sqrt(delta)) / (2 * a);
            return wynik;
        }
    }
}

