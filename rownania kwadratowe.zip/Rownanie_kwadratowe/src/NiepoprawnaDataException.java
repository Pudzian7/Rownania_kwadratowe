class NiepoprawnaDataException extends Exception {
    public NiepoprawnaDataException(String message) {
        super(message);
    }
}
